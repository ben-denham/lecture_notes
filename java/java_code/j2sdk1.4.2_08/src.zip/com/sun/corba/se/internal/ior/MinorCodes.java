/*
 * @(#)MinorCodes.java	1.4 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.corba.se.internal.ior ;

import com.sun.corba.se.internal.orbutil.ORBConstants ;

public class MinorCodes {
    private MinorCodes() {} 

    //////////////////////////////////////////////////////////////////////////////////
    // INTERNAL minor codes
    //////////////////////////////////////////////////////////////////////////////////
}
